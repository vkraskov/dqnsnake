# -*- coding: utf-8 -*-

from collections import deque

############

class Play:
	def __init__(self):
		self.init()

	def init(self):
		 a = 0

